package com.example.temperatureconversion

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

// Krista Agustin
// Temperature Conversion Performance Assessment
// November 22, 2026
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val txtTemperature =
            findViewById<EditText>(R.id.txtTemperature)
        val radFtoC =
            findViewById<RadioButton>(R.id.radFtoC)
        val btnConvert =
            findViewById<Button>(R.id.btnConvert)
        val txtResult =
            findViewById<TextView>(R.id.txtResult)

        btnConvert.setOnClickListener {

            val temperature =
                txtTemperature.text.toString().toDoubleOrNull()

            if (temperature == null) {
                Toast.makeText(
                    this,
                    "Please enter a valid temperature.",
                    Toast.LENGTH_LONG
                ).show()
                return@setOnClickListener
            }

            if (radFtoC.isChecked) {

                if (temperature < -100 || temperature > 250) {
                    Toast.makeText(
                        this,
                        "Fahrenheit must be between -100 and 250.",
                        Toast.LENGTH_LONG
                    ).show()
                    txtResult.text = ""
                } else {
                    val celsius = (temperature - 32) * 5 / 9
                    txtResult.text =
                        String.format("%.1f °C", celsius)
                }

            } else {

                if (temperature < -75 || temperature > 125) {
                    Toast.makeText(
                        this,
                        "Celsius must be between -75 and 125.",
                        Toast.LENGTH_LONG
                    ).show()
                    txtResult.text = ""
                } else {
                    val fahrenheit = (temperature * 9 / 5) + 32
                    txtResult.text =
                        String.format("%.1f °F", fahrenheit)
                }
            }
        }
    }
}
